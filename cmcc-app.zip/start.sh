#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 -m pip install -q --disable-pip-version-check requests cryptography >/dev/null 2>&1 || true
echo "启动中… 手机浏览器打开 http://127.0.0.1:8080"
exec python3 app.py
