#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""中国移动签到 · 手机网页控制台
手机浏览器打开 http://127.0.0.1:8080 ，点按钮即可，不用记命令。
"""
import json
import os
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

ROOT = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", "8080"))

PAGE = r'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>移动签到</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f3f5f9;font:16px/1.6 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:#1a1a1a}
.wrap{max-width:560px;margin:0 auto;padding:18px}
h1{font-size:22px;margin:6px 0 14px}
.card{background:#fff;border-radius:14px;padding:14px 16px;margin-bottom:14px;box-shadow:0 1px 4px rgba(0,0,0,.06);font-size:15px}
.btns{display:grid;gap:10px;margin-bottom:14px}
button{width:100%;padding:16px;border:0;border-radius:14px;background:#fff;font-size:17px;font-weight:600;color:#1a1a1a;box-shadow:0 1px 4px rgba(0,0,0,.06);cursor:pointer}
button.primary{background:#1677ff;color:#fff}
button.warn{background:#fff7e6;color:#ad6800}
button:active{opacity:.75}
pre{background:#10141c;color:#d6e2ff;border-radius:14px;padding:14px;min-height:180px;max-height:52vh;overflow:auto;font:12px/1.65 ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-all}
.tip{color:#888;font-size:13px;margin-top:12px;line-height:1.7}
</style></head><body>
<div class="wrap">
<h1>移动签到</h1>
<div class="card" id="info">正在自检…</div>
<div class="btns">
<button class="primary" onclick="run('status')">① 只查状态（不签到）</button>
<button class="primary" onclick="run('sign')">② 立即签到</button>
<button class="warn" onclick="run('refresh')">③ 现签一张新会话</button>
<button onclick="run('selftest')">重新自检</button>
</div>
<pre id="log">点上面按钮开始</pre>
<div class="tip">这个页面只在你手机本机运行，不上传任何数据。<br>浏览器菜单里选「添加到主屏幕」，就会变成一个 App 图标。</div>
</div>
<script>
async function run(a){
  const l=document.getElementById('log');
  l.textContent='运行中…最多等 3 分钟，别关页面';
  try{
    const r=await fetch('/run?action='+a,{method:'POST'});
    const d=await r.json();
    l.textContent=d.out||'(无输出)';
    document.getElementById('info').textContent = d.code===0 ? '✅ 这一步完成，看下面结果' : '⚠️ 有报错，看下面日志';
  }catch(e){l.textContent='连不上本机服务：'+e}
}
fetch('/run?action=selftest',{method:'POST'}).then(r=>r.json()).then(d=>{
  document.getElementById('info').textContent = d.code===0 ? '✅ 环境正常，直接点「立即签到」' : '⚠️ 环境有问题，看下面日志';
  document.getElementById('log').textContent=d.out||'(无输出)';
});
</script></body></html>'''

SELFTEST = (
    "python3 -c \"import requests, cryptography; print('依赖 OK: requests + cryptography')\" "
    "&& python3 -c \"import json;c=json.load(open('config.json'));"
    "t=c.get('session_template',{});print('号码尾号',c['phone'][-4:],'| 签名模板 xk',bool(t.get('xk')),'| cellNum',t.get('reqBody',{}).get('cellNum'))\" "
    "&& python3 cmcc_session.py --self-test"
)

CMDS = {
    "status":   "python3 cmcc_sign.py --config config.json --dry-run",
    "sign":     "python3 cmcc_sign.py --config config.json",
    "refresh":  "python3 cmcc_session.py --refresh --config config.json --phone 17274079953",
    "selftest": SELFTEST,
}


class Handler(BaseHTTPRequestHandler):
    def _send(self, obj):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        body = PAGE.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        q = parse_qs(urlparse(self.path).query)
        action = (q.get("action") or [""])[0]
        if action not in CMDS:
            return self._send({"out": "未知动作", "code": 1})
        env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
        try:
            p = subprocess.run(CMDS[action], shell=True, cwd=ROOT, env=env,
                               capture_output=True, text=True, timeout=180)
            out = (p.stdout or "") + (p.stderr or "")
            self._send({"out": out.strip() or "(脚本没有输出)", "code": p.returncode})
        except subprocess.TimeoutExpired:
            self._send({"out": "超时（3 分钟），可能卡在网络请求上", "code": 1})

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    print("=" * 46)
    print("  签到控制台已启动")
    print("  手机浏览器打开： http://127.0.0.1:%d" % PORT)
    print("  （同一台手机，别用别的设备开）")
    print("  按 Ctrl+C 停止")
    print("=" * 46)
    sys.stdout.flush()
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
